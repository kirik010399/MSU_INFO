#include <stdio.h>
#define EPS 0.0000001
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include "functions.h"

int main(void)
{
    double flag;
    int method, N=0;
    double deter=0;
    double *a;
    double *b;
    int val = 0;
    char name[120];
    char output[120];
    FILE *fin = NULL;
    FILE *fin2;
    
    printf("choose method of input:\n");
    printf("0 - random\n");
    printf("1 - input file\n");
    
    scanf("%d", &method);
    
    printf("choose size of the matrix:\n");
    scanf("%d",&N);
    
    a = (double*)malloc(N * N * sizeof (double));
    b = (double*)malloc(N * N * sizeof (double));
    
    if (method)
    {
        printf("enter the name of input file:\n");
        scanf("%s", name);
        fin = fopen(name, "r");
        
        if (!fin)
        {
            printf("file is wrong.\n");
            return -1;
        }
        
        val = GetMatrix(fin,N,a,b);
        
        if (val == -1)
            return val;
    }
    else
    {
        GenerateMatrix(N,a,b);
    }
    
    printf("enter the name of output file:\n");
    scanf("%s", output);
    fin2 = fopen(output, "w");
    
    PrintMatrix(fin2, N, a);
    
    fprintf(fin2, "\n"); 
    
    deter = det(a,N);
    PrintMatrix(fin2, N, a);
    flag = checkingIdentity(b,N);
    
    printf("determinant: %lf, checking: %lf\n", deter, flag);
    fclose (fin);
    fclose (fin2);
}

