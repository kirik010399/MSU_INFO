#include <stdio.h>
#define EPS 0.0000001
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include "functions.h"

int GetMatrix (FILE *fin,int N,double *a,double *b)
{
    int i=0,j=0,count=0;
    for (i = 0; i < N; ++i)
    {
        for (j = 0; j < N; ++j)
        {
            fscanf(fin, "%lf", &a[i*N+j]);
            b[i*N+j] = a[i*N+j];
            ++count;
        }
    }
    
    if (count != N*N)
    {
        printf("file is wrong.\n");
        return -1;
    }
    return 0; 
}
void GenerateMatrix(int N,double *a,double *b)
{
    int i=0,j=0;
    double r=0;
    for (i = 0; i < N; ++i)
    {
        for (j = 0; j < N; ++j)
        {
            r = rand()%1000000;
            r=r/1000000;
            r*=2;
            a[i*N+j] = r-1 ;
            b[i*N+j] = a[i*N+j];
        }
    }
}

void PrintMatrix(FILE *fin2,int N, double *a)
{
    int i=0,j=0;
    for (i = 0; i < N; ++i)
    {
        for (j = 0; j < N; ++j)
        {
            fprintf(fin2, "%.3lf ",a[i*N+j]);
            if ( ((i*N+j+1) % N ) == 0 )
                fprintf(fin2, "\n");
        }
    }
}

int search(double *a, int i, int N)//searching number of colomn with max element
{
    int k = i; int j=0;
    
    for (j = i + 1; j < N; ++j)
    {
        if (fabs (a[j*N+i]) > fabs (a[k*N+i]))
            k = j;
    }
    return k;
}

void swap_rows(double *a, double *b,int N)
{
    double t;
    int i=0;
    
    for (i = 0; i < N; i++)
    {
        t = a[i];
        a[i] = b[i];
        b[i] = t;
    }
}

void gauss(double *a, int i, int N)
{
    int j=0,k=0;
    for (j = i + 1; j < N; ++j)
    {
        a[i*N+j] /= a[i*N+i];
    }
    
    for (j = 0; j < N; ++j)
    {
        if (j != i && fabs(a[j*N+i]) > EPS)
        {
            for (k = i + 1; k < N; ++k)
            {
                a[j*N+k] -= a[i*N+k]*a[j*N+i];
            }
        }
    }
}

double det(double *a,int N)
{
    double det = 1;
    int k=0,i=0;
    
    for (i = 0; i < N; ++i)
    {
        k = search(a, i, N);
        
        if (fabs (a[k*N+i]) < EPS)
        {
            det = 0;
            break;
        }
        
        swap_rows(a+N*i, a+N*k, N);
        
        if (i != k)
            det = -det;
        
        det *= a[i*N+i];
        gauss(a, i, N);
    }
    
    for (int i = 0; i < N; ++i)
        for (int j = 0; j < N; ++j)
            if (i!=j)
                a[i*N+j] = 0;
    
    return det;
}

double checkingIdentity(double *b,int N)
{
    double deter1;
    
    swap_rows(b+N,b+2*N,N);
    deter1 = det(b,N);
    return (deter1);
    
}

