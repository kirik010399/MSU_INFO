int search(double *a, int i,int N);
void swap_rows(double *a, double *b,int N);
void gauss(double *a, int i, int N);
double det(double *a,int N);
double checkingIdentity(double *b,int N);
int GetMatrix (FILE *fin,int N,double *a,double *b);
void GenerateMatrix(int N,double *a,double *b);
void PrintMatrix(FILE *fin2,int N, double *a);

