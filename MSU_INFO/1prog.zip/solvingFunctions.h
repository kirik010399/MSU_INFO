#ifndef solvingFunctions_hpp
#define solvingFunctions_hpp

#include <stdio.h>

int solveSystem(double* matrix, double* vector, double* result, int *var, int n, float eps, int debug); 

#endif /* solvingFunctions_hpp */
