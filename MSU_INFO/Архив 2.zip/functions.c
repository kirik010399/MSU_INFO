#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define size 100

int my_strcmp (char *s1, char *s2)
{
    int i=0;
    
    while (s1[i] != '\0' || s2[i] != '\0')
    {
        if (s1[i] < s2[i]) return -1;
        if (s1[i] > s2[i]) return 1;
        ++i;
    }
    
    return 0;
}

char *my_strcpy(char *s1, char *s2)
{
    int i=0;
    while (s2[i]!='\0')
    {
        s1[i] = s2[i];
        ++i;
    }
    while (s1[i]!='\0')
    {
        s1[i] = 0;
        ++i;
    }
    return s1;
}

char *my_strcat(char *s1, char *s2)
{
    int i;
    unsigned long n = strlen(s1);
    unsigned long m = strlen(s2);
    
    for (i = 0; i < m; ++i)
    {
        s1[n+i]=s2[i];
    }
    return s1;
}

char *my_strset(char *s, char c)
{
    int i;
    unsigned long n = strlen(s);
    
    for (i = 0;i < n; ++i)
        s[i]=c;
    if (n==0)
        s[0]=c;
    return s;
}

char *my_strstr(char *s1, char *s2)
{
    int i=0,k,j=0;
    
    unsigned long n = strlen(s1);
    unsigned long m = strlen(s2);
    
    if (m==0||n==0)
        return NULL;
    if (n < m)
        return NULL;
    
    while (i < n && j!=m )
    {
        k = i;
        while (s2[j]==s1[k] && s1[k]!='\0')
        {
            j++;
            k++;
        }
        if (m == j)
        {
            k = k - j;
            return (&s1[k]);
        }
        i++;
        j=0;
    }
    return NULL;
}


