#ifndef functions_h
#define functions_h

int my_strcmp (char *s1, char *s2);
char *my_strcpy(char *s1, char *s2);
char *my_strcat(char *s1, char *s2);
char *my_strset(char *s, char c);
char *my_strstr(char *s1, char *s2);

#endif /* functions_h */

