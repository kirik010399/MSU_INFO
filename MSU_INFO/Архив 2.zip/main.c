#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "functions.h"
#define N 100

int main(void)
{
    char s1[N], s2[N], s3[N];
    char c;
    char* c2;

    printf("Enter the first string:\n");
    scanf("%s", s1);
    printf("Enter the second string:\n");
    scanf("%s", s2);

    printf("strcmp: %d\n", strcmp(s1,s2));
    printf("my strcmp: %d\n",my_strcmp(s1,s2));

    strcpy(s3, s1);
    printf("strcpy s1 into empty string: %s\n", s3);
    my_strcpy(s3, s1);
    printf("my strcpy s1 into empty string: %s\n", s3);

    strcat(s3,s2);
    printf("strcat(s1,s2), s1: %s\n", s3);
    strcpy(s3,s1);
    my_strcat(s3,s2);
    printf("my strcat(s1,s2), s1: %s\n", s3);

    printf("Enter char variable: \n");
    scanf("%s", &c);
    strcpy(s3, s1);
//    strset(s3, c);
//    printf("strset(s1, char), s1: %s\n", s3);
    strcpy(s3,s1);
    my_strset(s3,c);
    printf("my strset(s1, char), s1: %s\n",s3);

    c2 = strstr(s1,s2);
    printf("strstr(s1, s2): %s\n",c2);
    c2 = NULL;
    c2 = my_strstr(s1,s2);
    printf("my strstr(s1, s2): %s\n",c2);

    return 0;
}
