#ifndef functions_h
#define functions_h

#include <stdio.h>
#define EPS 0.0000001
#define N 3
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include "functions.h"

int search(double a[][N], int i);
void swap_rows(double a[][N], int i, int j);
double gauss(double a[][N], int i);
double det(double a[][N]);
double checkingIdentity(double b[][N]);

#endif /* functions_h */
