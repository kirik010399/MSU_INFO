#include <stdio.h>

int element(int i, int j, int n);
double f(int k, int n, int i, int j);
int vvod_matr(double* a, int n, int k, FILE* in);
void pechat_matr(double* a, int n, int m);
double norma(double* a, double* a_obr, int n);
