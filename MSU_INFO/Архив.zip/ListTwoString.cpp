//
//  ListTwoString.cpp
//  MSU_INFO
//
//  Created by Кирилл Мащенко on 28.10.2017.
//  Copyright © 2017 Кирилл Мащенко. All rights reserved.
//

#include "ListTwoString.hpp"
