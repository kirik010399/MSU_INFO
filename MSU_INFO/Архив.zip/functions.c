#include "functions.h"

int search(double a[][N], int i)//searching number of colomn with max element
{
    int k = i;
    
    for (int j = i + 1; j < N; ++j)
    {
        if (fabs (a[j][i]) > fabs (a[k][i]))
            k = j;
    }
    return k;
}

void swap_rows(double a[][N], int k, int l)
{
    double t;
    int i;
    
    for (i = 0; i < N; i++)
    {
        t = a[k][i];
        a[k][i] = a[l][i];
        a[l][i] = t;
    }
}

double gauss(double a[][N], int i)
{
    int k;
    double change = 1;
    
    k = search(a, i);
    
    if (fabs (a[k][i]) < EPS)
    {
        return 0;
    }
    
    swap_rows(a, i, k);
    
    if (i != k)
        change = -1;
    
    change *= a[i][i];
    
    for (int j = i + 1; j < N; ++j)
    {
        a[i][j] /= a[i][i];
    }
    
    for (int j = 0; j < N; ++j)
    {
        if (j != i && fabs(a[j][i]) > EPS)
        {
            for (int k = i + 1; k < N; ++k)
            {
                a[j][k] -= a[i][k]*a[j][i];
            }
        }
    }
    
    return change;
}

double det(double a[][N])
{
    double det = 1;
    double change;
    
    for (int i = 0; i < N; ++i)
    {
        change = gauss(a, i);
        
        if (change == 0)
        {
            return 0;
        }
        else
        {
            det *= change;
        }
    }
    
    return det;
}

double checkingIdentity(double b[][N])
{
    double deter1;
    
    swap_rows(b,1,2);
    deter1 = det(b);
    return (deter1);
}
