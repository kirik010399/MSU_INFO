#include <stdio.h>
int solve(double* a, double* b, double* x, int *ind, int n);
