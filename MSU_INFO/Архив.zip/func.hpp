#include <stdio.h>

double f(int k, int n, int i, int j);
int enter(double* a, double *b, int n, int k, FILE* in);
void print(double* a, int l, int n, int m);
double norm(double* a, double* b, double* x, int n);
double error(double *x, int n);

