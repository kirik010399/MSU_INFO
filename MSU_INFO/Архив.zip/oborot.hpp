#include <stdio.h>

int oborot(double* a, double* a_obr, double *x, int n);
