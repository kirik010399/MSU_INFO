#include <stdio.h>
#define EPS 0.0000001
#define N 3
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include "functions.h"

int main(void)
{
    double flag;
    int method;
    double deter;
    double r;
    double a[N][N];
    double b[N][N];
    int count = 0;
    char name[120];
    char output[120];
    FILE *fin = NULL;
    FILE *fin2;
    
    printf("choose method of input:\n");
    printf("0 - random\n");
    printf("1 - input file\n");
    
    scanf("%d", &method);
    
    if (method)
    {
        printf("enter the name of input file:\n");
        scanf("%s", name);
        fin = fopen(name, "r");
        
        if (!fin)
        {
            printf("file is wrong.\n");
            return -1;
        }
        
        for (int i = 0; i < N; ++i)
        {
            for (int j = 0; j < N; ++j)
            {
                if(fscanf(fin, "%lf", &a[i][j])!=EOF)
                {
                    b[i][j] = a[i][j];
                    ++count;
                }
            }
        }
        
        if (count != N*N)
        {
            printf("file is wrong.\n");
            return -1;
        }
    }
    else
    {
        for (int i = 0; i < N; ++i)
        {
            for (int j = 0; j < N; ++j)
            {
                r = rand()%1000000;
                r=r/1000000;
                r*=2;
                a[i][j] = r-1 ;
                b[i][j] = a[i][j];
            }
        }
    }
    
    printf("enter the name of output file:\n");
    scanf("%s", output);
    fin2 = fopen(output, "w");
    
    for (int i = 0; i < N; ++i)
    {
        for (int j = 0; j < N; ++j)
        {
            fprintf(fin2, "%.3lf ",a[i][j]);
        }
        fprintf(fin2, "\n");
    }
    
    deter = det(a);
    flag = checkingIdentity(b);
    
    printf("determinant: %lf, checking: %lf\n", deter, flag);
    
    if (method)
        fclose (fin);
    fclose (fin2);
}
