#ifndef solvingFunctions_hpp
#define solvingFunctions_hpp

#include <stdio.h>

int solveSystem(double* a, double* b, double* x, int n);

#endif /* solvingFunctions_hpp */
